const $ = id => document.getElementById(id);
const inr = n => "₹" + Number(n || 0).toLocaleString("en-IN");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fmt = d => d ? new Date(d).toLocaleDateString("en-IN") : "-";
const badge = s => `<span class="badge s-${String(s).replace(/\s/g,"")}">${esc(s)}</span>`;
function toast(t){const m=document.createElement("div");m.className="msg";m.setAttribute("role","status");m.textContent=t;document.body.append(m);setTimeout(()=>m.remove(),4000)}
function table(heads, rows){
  if(!rows.length) return '<p class="empty">Nothing to show yet.</p>';
  return `<div class="wrap"><table><thead><tr>${heads.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map((c,i)=>`<td data-l="${esc(heads[i])}">${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
async function requireUser(role){
  const {data:{session}} = await db.auth.getSession();
  if(!session){location.href="index.html";return null}
  const {data:p} = await db.from("profiles").select("*").eq("id",session.user.id).single();
  if(role==="admin" && p?.role!=="admin"){location.href="index.html";return null}
  if(!role && p?.role==="admin"){location.href="admin.html";return null}
  return {...p, email:session.user.email};
}
async function signedUrl(path){
  const {data,error} = await db.storage.from("documents").createSignedUrl(path,60);
  if(error){toast("Document could not be opened.");return}
  window.open(data.signedUrl,"_blank","noopener");
}
function tabs(names, onChange){
  const nav=$("tabs"); nav.innerHTML=names.map((n,i)=>`<button class="tab" data-t="${n}" ${i?"":'aria-current="page"'}>${n}</button>`).join("");
  nav.onclick=e=>{const b=e.target.closest(".tab");if(!b)return;nav.querySelectorAll(".tab").forEach(x=>x.removeAttribute("aria-current"));b.setAttribute("aria-current","page");onChange(b.dataset.t)};
  onChange(names[0]);
}
document.head.insertAdjacentHTML("beforeend",`<style>
:root{--ink:#16161a;--paper:#f6f4ef;--gold:#c8923a;--mute:#8b8b93}
*{box-sizing:border-box}body{margin:0;font:16px/1.5 Inter,system-ui,sans-serif;background:var(--paper);color:var(--ink)}
:focus-visible{outline:3px solid var(--gold);outline-offset:2px}
header{background:var(--ink);color:#fff;display:flex;justify-content:space-between;align-items:center;padding:14px 5vw;gap:10px;flex-wrap:wrap}
.brand{font:800 1.1rem Fraunces,Georgia,serif}
#tabs{display:flex;gap:6px;overflow-x:auto;padding:12px 5vw;background:#fff;border-bottom:1px solid #e3e0d8}
.tab{background:transparent;color:var(--ink);white-space:nowrap}.tab[aria-current]{background:var(--ink);color:#fff}
button{font:inherit;cursor:pointer;border:0;border-radius:6px;padding:8px 14px;background:var(--gold);color:#16161a;font-weight:600}
button.ghost{background:transparent;color:inherit;border:1px solid currentColor}button.sm{padding:4px 10px;font-size:.85rem;margin:2px}
button.danger{background:#c0392b;color:#fff}button:disabled{opacity:.5}
main{padding:28px 5vw}h2{font:700 1.5rem Fraunces,Georgia,serif;margin:0 0 16px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px;margin-bottom:24px}
.stat{background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 4px #0001}.stat b{display:block;font-size:1.6rem}.stat span{color:var(--mute);font-size:.85rem}
.wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px}
th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;font-size:.9rem;vertical-align:top}
.badge{padding:2px 9px;border-radius:99px;font-size:.78rem;font-weight:600;background:#eee}
.s-Pending,.s-Uploaded,.s-Held{background:#fdecc8}.s-Confirmed,.s-Verified,.s-Available,.s-FullyRefunded{background:#d5efdf}
.s-Rented,.s-Paid{background:#d6e6fa}.s-Returned,.s-PartiallyRefunded{background:#e4e0f5}.s-Cancelled,.s-Rejected{background:#f6d6d2}
.empty{color:var(--mute);padding:20px 0}
form.f{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;background:#fff;padding:16px;border-radius:10px;margin-bottom:20px}
label{display:flex;flex-direction:column;font-size:.8rem;gap:4px}input,select,textarea{font:inherit;padding:9px;border:1px solid #ccc;border-radius:6px;width:100%}
.msg{position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:var(--ink);color:#fff;padding:12px 18px;border-radius:8px;max-width:90vw;z-index:9}
.detail{background:#fff;padding:16px;border-radius:10px;margin:12px 0}
@media(max-width:640px){thead{display:none}tr{display:block;background:#fff;margin-bottom:10px;border-radius:8px}td{display:flex;justify-content:space-between;gap:12px;border:0}td::before{content:attr(data-l);color:var(--mute)}}
</style>`);

function pubHeader(){
  $("hdr").innerHTML = `<div class="brand">TB's Camera and Rental Equipments</div><nav style="display:flex;gap:14px;flex-wrap:wrap;font-size:.9rem">
  <a style="color:#fff" href="index.html">Home</a><a style="color:#fff" href="index.html#catalogue">Equipment</a><a style="color:#fff" href="info.html#how">How it works</a>
  <a style="color:#fff" href="info.html#about">About us</a><a style="color:#fff" href="info.html#contact">Contact</a><a style="color:#fff" href="customer.html">My account</a></nav>`;
}

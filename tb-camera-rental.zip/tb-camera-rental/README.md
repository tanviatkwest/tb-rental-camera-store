# TB's Camera and Rental Equipments
Stack: HTML/CSS/JS + Supabase (Postgres, Auth, Storage) + Vercel + GitHub.
1. Supabase > SQL Editor: run supabase/schema.sql, then patch_workflow.sql, then seed_10_products.sql.
2. Put your Project URL and anon key in config.js.
3. Supabase > Auth > Providers > Email: turn off "Confirm email" for easy demos.
4. Sign up on the site, then run in SQL Editor:
   update profiles set role='admin' where id=(select id from auth.users where email='YOU@EMAIL');
5. Push this folder to GitHub, import the repo in Vercel (framework: Other, no build command).
Pages: index, product, book, customer (dashboard), admin, info (how it works, about, contact, terms).

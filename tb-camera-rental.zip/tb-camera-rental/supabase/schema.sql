-- TB's Camera and Rental Equipments : Supabase (Postgres) schema
-- Run in Supabase Dashboard > SQL Editor. Then make yourself admin:
--   update profiles set role='admin' where id = (select id from auth.users where email='YOUR_EMAIL');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  name text not null, mobile text, address text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create table categories (
  category_id bigint generated always as identity primary key,
  category_name text not null unique, description text, created_at timestamptz default now()
);
create table equipment (
  equipment_id bigint generated always as identity primary key,
  category_id bigint not null references categories,
  name text not null, brand text, model text, description text, specifications text,
  rental_price numeric(10,2) not null check (rental_price >= 0),
  security_deposit numeric(10,2) not null default 0 check (security_deposit >= 0),
  status text not null default 'Available'
    check (status in ('Available','Reserved','Rented','Under Repair','Unavailable')),
  is_active boolean not null default true,   -- soft delete
  image text, created_at timestamptz default now(), updated_at timestamptz default now()
);
create table rentals (
  rental_id bigint generated always as identity primary key,
  booking_code text unique,
  customer_id uuid not null references profiles,
  pickup_date date not null, return_date date not null,
  rental_days int not null, rental_amount numeric(10,2) not null,
  deposit_amount numeric(10,2) not null, total_amount numeric(10,2) not null,
  status text not null default 'Pending'
    check (status in ('Pending','Confirmed','Rented','Returned','Cancelled')),
  created_at timestamptz default now(), updated_at timestamptz default now(),
  check (return_date > pickup_date)
);
create table rental_items (
  rental_item_id bigint generated always as identity primary key,
  rental_id bigint not null references rentals on delete cascade,
  equipment_id bigint not null references equipment,
  quantity int not null default 1, price numeric(10,2) not null
);
create table documents (
  document_id bigint generated always as identity primary key,
  customer_id uuid not null references profiles,
  document_type text not null check (document_type in ('Identity Proof','Address Proof')),
  document_file text not null,  -- path inside private 'documents' bucket
  verification_status text not null default 'Uploaded'
    check (verification_status in ('Uploaded','Under Verification','Verified','Rejected')),
  rejection_reason text, created_at timestamptz default now(), verified_at timestamptz
);
create table payments (
  payment_id bigint generated always as identity primary key,
  rental_id bigint not null references rentals, amount numeric(10,2) not null,
  payment_type text, transaction_id text,
  payment_status text not null default 'Pending' check (payment_status in ('Pending','Paid','Failed','Refunded')),
  payment_date timestamptz default now()
);
create table returns (
  return_id bigint generated always as identity primary key,
  rental_id bigint not null unique references rentals, return_date date not null,
  condition_status text not null check (condition_status in ('Good','Minor Damage','Major Damage','Lost')),
  damage_amount numeric(10,2) not null default 0, remarks text, created_at timestamptz default now()
);
create table deposits (
  deposit_id bigint generated always as identity primary key,
  rental_id bigint not null unique references rentals, deposit_amount numeric(10,2) not null,
  deduction numeric(10,2) not null default 0, refund_amount numeric(10,2) not null default 0,
  refund_status text not null default 'Held' check (refund_status in ('Held','Partially Refunded','Fully Refunded')),
  refund_date date
);
create index on rentals (customer_id);
create index on rentals (status, pickup_date, return_date);
create index on rental_items (equipment_id);
create index on equipment (category_id);

-- ---------- helpers ----------
create function is_admin() returns boolean language sql security definer stable as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;

-- auto-create profile on signup
create function handle_new_user() returns trigger language plpgsql security definer as $$
begin
  insert into profiles (id, name, mobile, address)
  values (new.id, coalesce(new.raw_user_meta_data->>'name',''),
          new.raw_user_meta_data->>'mobile', new.raw_user_meta_data->>'address');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- ---------- availability engine (server-side) ----------
-- Overlap rule: existing.pickup < new.return AND existing.return > new.pickup
-- so a booking ending 12 Oct does not block one starting 12 Oct.
create function check_availability(p_equipment bigint, p_pickup date, p_return date)
returns boolean language sql security definer stable as $$
  select p_return > p_pickup
    and exists (select 1 from equipment e where e.equipment_id = p_equipment
                and e.is_active and e.status not in ('Under Repair','Unavailable'))
    and not exists (
      select 1 from rental_items ri join rentals r using (rental_id)
      where ri.equipment_id = p_equipment
        and r.status in ('Pending','Confirmed','Rented')
        and r.pickup_date < p_return and r.return_date > p_pickup)
$$;

-- ---------- booking: totals are always recalculated here ----------
create function create_rental(p_items bigint[], p_pickup date, p_return date)
returns text language plpgsql security definer as $$
declare
  v_days int := p_return - p_pickup; v_rent numeric := 0; v_dep numeric := 0;
  v_id bigint; v_code text; eid bigint;
begin
  if auth.uid() is null then raise exception 'Please log in first.'; end if;
  if p_pickup < current_date or v_days < 1 then raise exception 'Please select a valid return date.'; end if;
  if coalesce(array_length(p_items,1),0) = 0 then raise exception 'Select at least one item.'; end if;
  foreach eid in array p_items loop
    if not check_availability(eid, p_pickup, p_return) then
      raise exception 'This equipment is unavailable for the selected dates.';
    end if;
  end loop;
  select sum(rental_price) * v_days, sum(security_deposit) into v_rent, v_dep
    from equipment where equipment_id = any(p_items);
  insert into rentals (customer_id, pickup_date, return_date, rental_days, rental_amount, deposit_amount, total_amount)
    values (auth.uid(), p_pickup, p_return, v_days, v_rent, v_dep, v_rent + v_dep) returning rental_id into v_id;
  v_code := 'RC-' || extract(year from now())::int || '-' || lpad(v_id::text, 5, '0');
  update rentals set booking_code = v_code where rental_id = v_id;
  insert into rental_items (rental_id, equipment_id, price)
    select v_id, equipment_id, rental_price * v_days from equipment where equipment_id = any(p_items);
  insert into deposits (rental_id, deposit_amount) values (v_id, v_dep);
  return v_code;
end $$;

-- ---------- Row Level Security ----------
alter table profiles enable row level security;     alter table categories enable row level security;
alter table equipment enable row level security;    alter table rentals enable row level security;
alter table rental_items enable row level security; alter table documents enable row level security;
alter table payments enable row level security;     alter table returns enable row level security;
alter table deposits enable row level security;

create policy "own profile" on profiles for select using (id = auth.uid() or is_admin());
create policy "edit own profile" on profiles for update using (id = auth.uid())
  with check (id = auth.uid() and role = 'customer');
create policy "public read categories" on categories for select using (true);
create policy "admin categories" on categories for all using (is_admin()) with check (is_admin());
create policy "public read equipment" on equipment for select using (is_active or is_admin());
create policy "admin equipment" on equipment for all using (is_admin()) with check (is_admin());
create policy "own rentals" on rentals for select using (customer_id = auth.uid() or is_admin());
create policy "admin update rentals" on rentals for update using (is_admin());
create policy "own items" on rental_items for select using (
  exists (select 1 from rentals r where r.rental_id = rental_items.rental_id and (r.customer_id = auth.uid() or is_admin())));
create policy "own documents" on documents for select using (customer_id = auth.uid() or is_admin());
create policy "upload documents" on documents for insert with check (customer_id = auth.uid());
create policy "admin verify documents" on documents for update using (is_admin());
create policy "own payments" on payments for select using (
  exists (select 1 from rentals r where r.rental_id = payments.rental_id and (r.customer_id = auth.uid() or is_admin())));
create policy "admin payments" on payments for all using (is_admin()) with check (is_admin());
create policy "own returns" on returns for select using (
  exists (select 1 from rentals r where r.rental_id = returns.rental_id and (r.customer_id = auth.uid() or is_admin())));
create policy "admin returns" on returns for all using (is_admin()) with check (is_admin());
create policy "own deposits" on deposits for select using (
  exists (select 1 from rentals r where r.rental_id = deposits.rental_id and (r.customer_id = auth.uid() or is_admin())));
create policy "admin deposits" on deposits for all using (is_admin()) with check (is_admin());

-- Private document storage: each user writes/reads only inside a folder named with their user id
insert into storage.buckets (id, name, public) values ('documents','documents',false);
create policy "upload own docs" on storage.objects for insert to authenticated
  with check (bucket_id='documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "read own docs" on storage.objects for select to authenticated
  using (bucket_id='documents' and ((storage.foldername(name))[1] = auth.uid()::text or is_admin()));

-- ---------- seed data ----------
insert into categories (category_name) values ('Cameras'),('Lenses'),('Tripods'),('Camera Bags'),('LED Lights'),('Microphones'),('Accessories');
insert into equipment (category_id, name, brand, model, description, rental_price, security_deposit) values
 (1,'Sony A7 IV','Sony','A7 IV','33MP full-frame mirrorless, 4K video.',2000,10000),
 (1,'Canon EOS R6','Canon','EOS R6','Full-frame mirrorless for stills and video.',1800,9000),
 (1,'Nikon Z6 II','Nikon','Z6 II','Versatile full-frame hybrid camera.',1700,9000),
 (1,'Sony A6400','Sony','A6400','Compact APS-C mirrorless with fast autofocus.',1000,5000),
 (1,'Canon EOS 90D','Canon','EOS 90D','32.5MP DSLR for events and travel.',900,5000),
 (2,'Sony 24-70mm Lens','Sony','24-70mm',null,1000,5000),
 (2,'Sony 50mm Lens','Sony','50mm',null,500,2500),
 (2,'Canon 24-105mm Lens','Canon','24-105mm',null,900,4500),
 (3,'Tripod','Generic','Pro tripod',null,300,1000),
 (4,'Camera Bag','Generic','Padded bag',null,200,500),
 (5,'LED Light','Generic','LED panel',null,500,2000),
 (6,'Microphone','Generic','Shotgun mic',null,400,1500);

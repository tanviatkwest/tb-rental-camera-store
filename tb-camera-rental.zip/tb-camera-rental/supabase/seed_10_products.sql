-- Run after schema.sql: replaces the starter seed with 10 camera-related products.
-- To use real photos later: update equipment set image='https://...jpg' where equipment_id=1;
delete from equipment;
insert into equipment (category_id, name, brand, model, description, specifications, rental_price, security_deposit) values
(1,'Sony A7 IV','Sony','A7 IV','Professional full-frame mirrorless for photography, video, events and portraits.','33MP full-frame sensor; 4K 60p video; 10-bit colour; Wi-Fi; dual card slots',2000,10000),
(1,'Canon EOS R6','Canon','EOS R6','Fast full-frame mirrorless with excellent low-light performance.','20MP sensor; 4K 60p; 12 fps mechanical shutter; in-body stabilisation',1800,9000),
(1,'Nikon Z6 II','Nikon','Z6 II','Versatile full-frame hybrid camera for stills and video.','24.5MP sensor; 4K 60p; dual processors; 5-axis stabilisation',1700,9000),
(1,'Sony A6400','Sony','A6400','Compact APS-C mirrorless with fast real-time autofocus, ideal for vlogging.','24MP APS-C sensor; 4K video; tilting touchscreen; 11 fps',1000,5000),
(2,'Sony FE 24-70mm f/2.8 GM','Sony','SEL2470GM','Professional standard zoom lens for weddings and events.','24-70mm; f/2.8 constant aperture; E-mount full-frame; weather sealed',1000,5000),
(2,'Canon RF 24-105mm f/4L','Canon','RF 24-105mm','All-round L-series zoom for RF-mount cameras.','24-105mm; f/4 constant aperture; image stabiliser; weather sealed',900,4500),
(3,'Manfrotto Video Tripod','Manfrotto','MVK500','Sturdy fluid-head tripod for smooth pans and long shoots.','Fluid head; aluminium legs; max load 5 kg; height up to 160 cm',300,1000),
(5,'Godox LED Video Light','Godox','SL60W','Daylight LED panel for interviews, product shots and portraits.','60W; 5600K; Bowens mount; adjustable brightness; softbox-ready',500,2000),
(6,'Rode VideoMic Pro+','Rode','VideoMic Pro+','On-camera shotgun microphone with clear directional audio.','Supercardioid pattern; 3.5mm output; battery or USB powered; shock mount',400,1500),
(7,'DJI RS 3 Gimbal','DJI','RS 3','3-axis handheld gimbal for smooth, stable video.','3-axis stabilisation; 3 kg payload; touchscreen; up to 12 h battery',700,4000);

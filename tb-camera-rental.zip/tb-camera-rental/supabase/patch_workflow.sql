-- Run after schema.sql. Enforces status workflow and adds return/refund logic.

create function enforce_status_flow() returns trigger language plpgsql security definer as $$
begin
  if new.status = old.status then return new; end if;
  if not ((old.status='Pending'   and new.status in ('Confirmed','Cancelled'))
       or (old.status='Confirmed' and new.status in ('Rented','Cancelled'))
       or (old.status='Rented'    and new.status = 'Returned')) then
    raise exception 'Invalid status change: % to %', old.status, new.status;
  end if;
  if not is_admin() and not (old.status='Pending' and new.status='Cancelled') then
    raise exception 'Not allowed.';
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger rentals_flow before update on rentals for each row execute function enforce_status_flow();

-- customers may cancel only their own Pending rentals (trigger blocks everything else)
create policy "cancel own pending" on rentals for update
  using (customer_id = auth.uid() and status = 'Pending') with check (customer_id = auth.uid());

-- Admin records return: Refund = Deposit - Damage (never below 0)
create function process_return(p_rental bigint, p_condition text, p_damage numeric, p_remarks text)
returns void language plpgsql security definer as $$
declare v_dep numeric;
begin
  if not is_admin() then raise exception 'Not allowed.'; end if;
  if (select status from rentals where rental_id = p_rental) <> 'Rented' then
    raise exception 'Only a Rented booking can be returned.'; end if;
  select deposit_amount into v_dep from deposits where rental_id = p_rental;
  p_damage := least(greatest(coalesce(p_damage,0),0), v_dep);
  insert into returns (rental_id, return_date, condition_status, damage_amount, remarks)
    values (p_rental, current_date, p_condition, p_damage, p_remarks);
  update deposits set deduction = p_damage, refund_amount = v_dep - p_damage where rental_id = p_rental;
  update rentals set status = 'Returned' where rental_id = p_rental;
end $$;

create function process_refund(p_rental bigint) returns void language plpgsql security definer as $$
begin
  if not is_admin() then raise exception 'Not allowed.'; end if;
  if (select status from rentals where rental_id = p_rental) <> 'Returned' then
    raise exception 'Record the return first.'; end if;
  update deposits set refund_date = current_date,
    refund_status = case when deduction > 0 then 'Partially Refunded' else 'Fully Refunded' end
  where rental_id = p_rental and refund_status = 'Held';
end $$;

create function record_payment(p_rental bigint, p_type text, p_txn text) returns void
language plpgsql security definer as $$
begin
  if not is_admin() then raise exception 'Not allowed.'; end if;
  insert into payments (rental_id, amount, payment_type, transaction_id, payment_status)
    select rental_id, total_amount, p_type, p_txn, 'Paid' from rentals where rental_id = p_rental;
end $$;

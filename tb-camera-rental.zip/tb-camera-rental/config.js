// Paste your Supabase values ONCE here (Project Settings > API). Anon key is safe to publish; RLS protects data.
const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-ANON-KEY";
const db = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
// Product image: uses equipment.image (any image URL) if set, otherwise a built-in illustration by category.
const _ic = {
 Cameras:'<rect x="35" y="70" width="130" height="75" rx="8"/><circle cx="100" cy="108" r="26"/><circle cx="100" cy="108" r="10"/><path d="M70 70l8-14h44l8 14"/>',
 Lenses:'<rect x="55" y="55" width="90" height="90" rx="8"/><circle cx="100" cy="100" r="30"/><circle cx="100" cy="100" r="12"/>',
 Tripods:'<path d="M100 35v70M100 105L60 170M100 105L140 170M100 105v65"/><rect x="82" y="30" width="36" height="12"/>',
 "LED Lights":'<rect x="45" y="55" width="110" height="70" rx="6"/><path d="M60 140h80M100 125v25"/><circle cx="75" cy="90" r="6"/><circle cx="100" cy="90" r="6"/><circle cx="125" cy="90" r="6"/>',
 Microphones:'<rect x="85" y="40" width="30" height="70" rx="15"/><path d="M65 95a35 35 0 0 0 70 0M100 130v30M80 160h40"/>',
 Accessories:'<rect x="60" y="85" width="80" height="50" rx="6"/><path d="M100 85V50M85 50h30"/><circle cx="100" cy="110" r="12"/>',
 "Camera Bags":'<rect x="50" y="75" width="100" height="75" rx="10"/><path d="M80 75v-15h40v15M50 105h100"/>'};
function productImg(e){
  if (e.image) return e.image;
  const n = e.categories?.category_name || "Accessories";
  return "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#222228"/><g fill="none" stroke="#c8923a" stroke-width="4" stroke-linejoin="round">${_ic[n]||_ic.Accessories}</g></svg>`);
}
